/*
 *	Lab Section: 022	
 *	Assignment: Lab 1 Exercise 2
 *	Exercise Description: Port A's pins 3 to 0, each connect to 
 *	a parking space sensor, 1 meaning a car is parked in the space, 
 *	of a four-space parking lot. Write a program that outputs in 
 *	binary on port C the number of available spaces (Hint: declare 
 *	a variable "unsigned char cntavail"; you can assign a number 
 *	to a port as follows: PORTC = cntavail;).
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */ 

#include <avr/io.h>
#include <stdio.h>
int main(void){
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRC = 0xFF; PORTC = 0x00; // Configure port B's 8 pins as outputs
	// Initialize output on PORTB to 0x00
	unsigned char cntAvail = 0x00;
	//unsigned char tmpA = 0x00;
	while(1){
		//tmpA = PINA;
		switch (PINA){
			case 0x00:
				cntAvail = 0x04;
				break;
			case 0x01:
				cntAvail = 0x03;
				break;
			case 0x02:
				cntAvail = 0x02;
				break;
			case 0x03:
				cntAvail = 0x01;
				break;
			case 0x04:
				cntAvail = 0x00;
				break;
			default : 
				printf("Invalid input\n");
		}
		PORTC = cntAvail;
	}
}


